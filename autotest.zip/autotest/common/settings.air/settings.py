# -*- encoding=utf8 -*-
__author__ = "riddle"

from airtest.core.api import *
from airtest.core.settings import Settings as ST
from airtest.core.error import TargetNotFoundError,AirtestError
from airtest.core.api import *
import os,sys
from operator import methodcaller


# ST.RESIZE_METHOD = custom_resize_method
# ST.THRESHOLD = 0.65#图像识别阈值,默认为0.6
# ST.THRESHOLD_STRICT = 0.7#断言的图像识别阈值，默认为0.7
# ST.RESIZE_METHOD#在具有不同分辨率的设备中重新定义屏幕缩放定律
# ST.LOG_FILE#日志文件名，默认名称为log.txt
# ST.OPDELAY#当前操作后等待下一次操作多长时间，默认延迟为0.1s
# ST.FIND_TIMEOUT#图像匹配超时，默认为20秒 
# device = os.popen('adb shell getprop ro.product.model').read()   
# print(device)  

#现在连接的手机
phone_width = 2140
phone_height = 1080
left_side = 0#加上左右的尺寸





class ClickInvalidError(AirtestError):
    """按钮无效异常"""
    pass
class ControlOrAgentNotSetError(AirtestError):
    """总控或者代理未设置"""
    pass

#超时判断
def chaoshi(start_time,timeout=120):
    if (time.time() - start_time) > timeout:
        return False
    else:
        return True
#等待判断
def pc_wait(picture,miaoshu='',timeout=120):
    start_time = time.time()
    while True:
        if exists(picture):
            assert_exists(picture,miaoshu)
            return True
        if (time.time() - start_time) > timeout:
            raise TargetNotFoundError(miaoshu)
            return False
        else:
            time.sleep(3)

            
# 异常列表
except_list = [] #需要定义全局变量
class Except_list:        
    def add_except(self,exception):
        print(exception)
        except_list.append(exception)
        
    def show_except(self):
        except_no = len(except_list)
        print("\n---------------------------一共有%d异常----------------------------\n"%except_no)
        if except_no != 0:
            for exception in except_list:
                print(exception)
                      


# 连接设备
def connect_phone():
    shebei = os.popen('adb devices').readlines()
    for i in range(len(shebei)):
            if shebei[i].find('\tdevice') != -1:
                temp = shebei[i].split('\t')
                DEV = temp[0]
    connect_device("Android://127.0.0.1:5037/"+DEV)    
    
# 重启app
def reboot_app():
    stop_app('org.cocos2d.huihuang_online')
    sleep(2)
    start_app('org.cocos2d.huihuang_online')  #启动对应app
    return pc_wait(Template(r"tpl1548467116180.png",rgb=True, record_pos=(0.024, -0.103), resolution=(2280, 1080)))

# 重启手机
def reboot_phone(login_again):
    count = 0
    while True:
        os.popen('adb reboot')
        count += 1
        sleep(15)
        connect_phone()    
        wake()
        if login_again():
            break
        else:
            print("---------------------------重启手机失败%d次--------------------------"%count)


# cls是要测试的类
# exc_func是异常要执行的函数            
#sort默认为False,表示随机，如果是True,对比方法最后一位，则按顺序调用
def test_class(cls,exc_func,sort=False):
    test = cls() 
#     sleep(10)#先等实例的初始化先跑完
    methods = dir(test)
    method_list = []
    for method in methods:
        if method.startswith("test_"):
            method_list.append(method)
#     筛选
    def sift(methods):
        n = methods[-2:]
        if not n.isdigit():
            n = n[1:]
        return int(n)
            
#     判断是否需要排序
    if sort:
        method_list = sorted(method_list,key=sift)        
        
    print(method_list)
    
#     遍历出来，调用方法
    for run_method in method_list:
        try:
            methodcaller(run_method)(test)
        except Exception as e:
            Except_list().add_except("---------------------------运行{}{}报错--------------------------".format(test.__doc__,run_method))
            print(e) 
            islobby = exc_func()

# game是要测试的游戏
# exc_func是异常要执行的函数                
def test_game(game,login_again,webside):
    try:
        with game(webside) as (test,result):
            if result:
                methods = dir(test)
                method_list = []
                for method in methods:
                    if method.startswith("test_"):
                        method_list.append(method)

                print(method_list)

    #                 遍历出来，调用方法
                for run_method in method_list:
                    try:
                        methodcaller(run_method)(test)
                    except TargetNotFoundError as e:
                        Except_list().add_except("---------------------------运行{}{}报错--------------------------".format(test.__doc__,run_method))
                        print(e) 
                        islobby = login_again()
                        if not islobby:
                            test.exit()
#                             close_windows(webside)
                            test.ingame()
                        else:
                            if not method_list[len(method_list)-1] == run_method:  
                                test.ingame()
    except ControlOrAgentNotSetError as e:
        print(e)
        Except_list().add_except("---------------------------{}代理已设置禁用、维护、开发中等----------------------".format(game.__doc__))
    except Exception as e:
        print(e)
        Except_list().add_except("---------------------------运行{}报错，走下一个游戏----------------------".format(game.__doc__))
        if not login_again():
            reboot_phone(login_again)
            
                            
def coordinate(l=[],width=None,height=None):
    # 默认手机尺寸
    if width == None:       
        default_width = 2140
    else:
        default_width = width
    if height == None:
        default_height = 1080
    else:
        default_height = height
        
    global phone_width
    phone_width -= left_side

#     改变尺寸
    w = phone_width / default_width
    l[0] = round(l[0]*w)+left_side

    h = phone_height / default_height
    l[1] = round(l[1] * h)
        
    return l

    
def bug_dir(name):
    path = os.path.abspath('..')+r'\bug_photos\{}'.format(name)
    return path

def verify_dir(name):
    path = os.path.abspath('..')+r'\verify.air\{}'.format(name)
    return path

def bug_assert(picture,note,failNote=None):
    try:
        assert_exists(picture,'测试' + note)
        return True
    except AssertionError:
#         if failNote == None:
#             snapshot(filename=bug_dir(note + '失败.jpg'))
#             print(note + '失败')
#         else:
#             snapshot(filename=bug_dir(failNote + '.jpg'))
#             print(failNote)
#         sleep(5)
        return False
          
def bug_assert_not(picture,note,failNote=None):    
    try:
        assert_not_exists(picture,'测试' + note)
        return True
    except AssertionError:
        if failNote == None:
            snapshot(filename=bug_dir(note + '失败.jpg'))
            print(note + '失败')
        else:
            snapshot(filename=bug_dir(failNote + '.jpg'))
            print(failNote)
        sleep(5)
        return False
    
    
   

