# -*- encoding=utf8 -*-
__author__ = "zhandian"

from airtest.core.api import *

def leimu_P(web):
    photos = {"yaoji":[Template(r"tpl1550656496180.png", rgb=True, record_pos=(-0.346, -0.016), resolution=(1920, 1080)),Template(r"tpl1550715739222.png", record_pos=(-0.347, 0.054), resolution=(1920, 1080)),Template(r"tpl1550715753339.png", record_pos=(-0.351, 0.132), resolution=(1920, 1080))],
              "huihuang100":[Template(r"tpl1550734642794.png", rgb=True, record_pos=(-0.347, -0.015), resolution=(1920, 1080)),Template(r"tpl1550734658841.png", record_pos=(-0.342, 0.132), resolution=(1920, 1080)),Template(r"tpl1550734671196.png", record_pos=(-0.344, 0.059), resolution=(1920, 1080))]}
    return photos[web]

#游戏大厅游戏名称
def dating(web,game):
    photos = {"yaoji":{"Game_errenniuniu":Template(r"tpl1550651092203.png", rgb=True, record_pos=(-0.119, 0.14), resolution=(1920, 1080)),"Game_qiangzhuangniuniu":Template(r"tpl1550713191955.png", threshold=0.9, rgb=True, record_pos=(0.36, -0.035), resolution=(1920, 1080))
    ,"Game_shisanshui":Template(r"tpl1550714180874.png", rgb=True, record_pos=(0.024, -0.038), resolution=(1920, 1080))
    ,"Game_erbagang":Template(r"tpl1550656951700.png", rgb=True, record_pos=(0.258, 0.138), resolution=(1920, 1080))
    ,"Game_ershiyidian":Template(r"tpl1550657065017.png", rgb=True, record_pos=(0.383, -0.038), resolution=(1920, 1080))
    ,"Game_fuguisangong":Template(r"tpl1550657120112.png", rgb=True, record_pos=(0.21, -0.038), resolution=(1920, 1080))
    ,"Game_yazhuanglonghu":Template(r"tpl1550657196760.png", rgb=True, record_pos=(0.101, 0.139), resolution=(1920, 1080))
    ,"Game_tongbiniuniu":Template(r"tpl1550657292024.png", rgb=True, record_pos=(0.309, 0.139), resolution=(1920, 1080))
    ,"Game_huanlesanshimiao":Template(r"tpl1550657386689.png", rgb=True, record_pos=(-0.139, 0.138), resolution=(1920, 1080))       ,"Game_qiangzhuangpaijiu":Template(r"tpl1550657444018.png", rgb=True, record_pos=(0.1, -0.037), resolution=(1920, 1080))
    ,"Game_hongheibigwar":None               ,"Game_hundredCattle":Template(r"tpl1550658205461.png", rgb=True, record_pos=(-0.094, -0.035), resolution=(1920, 1080))
    ,"Game_landlord":None,"Game_texasholdem":Template(r"tpl1550714421012.png", record_pos=(0.143, 0.14), resolution=(1920, 1080))
    ,"Game_FriedGoldenFlower":Template(r"tpl1550658524639.png", rgb=True, record_pos=(0.201, -0.037), resolution=(1920, 1080)),"Game_benzBmw":Template(r"tpl1550657683484.png", rgb=True, record_pos=(-0.099, 0.138), resolution=(1920, 1080))
    ,"Game_birdBeast":Template(r"tpl1550657784071.png", rgb=True, record_pos=(-0.097, -0.039), resolution=(1920, 1080)),"Game_shake":Template(r"tpl1550657829276.png", rgb=True, record_pos=(0.139, -0.039), resolution=(1920, 1080))
    ,"Game_goldcarp":Template(r"tpl1550657955563.png", rgb=True, record_pos=(0.14, -0.036), resolution=(1920, 1080)),"Game_splitfish":Template(r"tpl1550657929053.png", record_pos=(-0.099, -0.039), resolution=(1920, 1080))
    ,"Game_nazhanaohai":Template(r"tpl1550658110464.png", rgb=True, record_pos=(-0.102, 0.139), resolution=(1920, 1080))
    },"huihuang100":{"Game_landlord":Template(r"tpl1550734786247.png", rgb=True, record_pos=(-0.069, 0.148), resolution=(1920, 1080))       ,"Game_FriedGoldenFlower":Template(r"tpl1550735580412.png", rgb=True, record_pos=(0.169, -0.043), resolution=(1920, 1080)),"Game_errenniuniu":  Template(r"tpl1550744861027.png", threshold=0.8, rgb=True, record_pos=(0.11, -0.043), resolution=(1920, 1080)),"Game_qiangzhuangniuniu":Template(r"tpl1550744776367.png", threshold=0.8, rgb=True, record_pos=(0.167, -0.043), resolution=(1920, 1080))
    ,"Game_shisanshui":Template(r"tpl1550745376610.png", rgb=True, record_pos=(0.098, -0.043), resolution=(1920, 1080))
    ,"Game_erbagang":Template(r"tpl1550745403882.png", threshold=0.8, rgb=True, record_pos=(0.045, 0.149), resolution=(1920, 1080))
    ,"Game_ershiyidian":Template(r"tpl1550745447946.png", rgb=True, record_pos=(0.049, -0.043), resolution=(1920, 1080))
    ,"Game_fuguisangong":Template(r"tpl1550745469585.png", rgb=True, record_pos=(0.029, 0.15), resolution=(1920, 1080))
    ,"Game_yazhuanglonghu":Template(r"tpl1550745490187.png", rgb=True, record_pos=(0.001, -0.043), resolution=(1920, 1080))
    ,"Game_tongbiniuniu":Template(r"tpl1550745507985.png", rgb=True, record_pos=(-0.028, 0.15), resolution=(1920, 1080))
    ,"Game_huanlesanshimiao":Template(r"tpl1550745534439.png", rgb=True, record_pos=(0.371, -0.043), resolution=(1920, 1080))
    ,"Game_qiangzhuangpaijiu":Template(r"tpl1550745551956.png", rgb=True, record_pos=(0.135, -0.043), resolution=(1920, 1080))
    ,"Game_hongheibigwar":None               
    ,"Game_hundredCattle":Template(r"tpl1550745602287.png", rgb=True, record_pos=(-0.069, -0.042), resolution=(1920, 1080))
    ,"Game_landlord":None
    ,"Game_texasholdem":Template(r"tpl1550745642564.png", rgb=True, record_pos=(0.167, 0.151), resolution=(1920, 1080))
    ,"Game_FriedGoldenFlower":Template(r"tpl1550745667871.png", rgb=True, record_pos=(0.129, 0.151), resolution=(1920, 1080))
    ,"Game_benzBmw":Template(r"tpl1550745691799.png", rgb=True, record_pos=(-0.067, -0.043), resolution=(1920, 1080))
    ,"Game_birdBeast":Template(r"tpl1550745707619.png", rgb=True, record_pos=(-0.068, 0.149), resolution=(1920, 1080))
    ,"Game_shake":Template(r"tpl1550745722841.png", rgb=True, record_pos=(0.163, -0.043), resolution=(1920, 1080))
    ,"Game_goldcarp":Template(r"tpl1550745750092.png", rgb=True, record_pos=(-0.073, -0.041), resolution=(1920, 1080))
    ,"Game_splitfish":Template(r"tpl1550745765567.png", record_pos=(-0.078, 0.152), resolution=(1920, 1080))
    ,"Game_nazhanaohai":Template(r"tpl1550745776869.png", rgb=True, record_pos=(0.167, -0.038), resolution=(1920, 1080))}}
  
    return photos[web][game]
#充值界面
def money(web):
    photos = {"huihuang100":[Template(r"tpl1550734070482.png", rgb=True, record_pos=(0.005, -0.235), resolution=(1920, 1080)),Template(r"tpl1550734095191.png", rgb=True, record_pos=(-0.448, -0.246), resolution=(1920, 1080))],"yaoji":[Template(r"tpl1550638965586.png", rgb=True, record_pos=(-0.002, -0.239), resolution=(1920, 1080)),Template(r"tpl1550639023074.png", rgb=True, record_pos=(-0.447, -0.245), resolution=(1920, 1080))]}
    return photos[web]

# app包
def app_package(webside):
    packages = {'huihuang100':'org.cocos2d.huihuang_online','wangzhe':'org.cocos2d.wangzhe001_online','yaoji':'org.cocos2d.wg0001_online'}
    return packages[webside]

# 登录后的窗口图片
def windows_p(webside,name):
    if webside == 'huihuang100':        
        photos = {'activity':Template(r"tpl1549449519498.png", rgb=True, record_pos=(0.367, -0.184), resolution=(2280, 1080)),'checkIn':Template(r"tpl1549449561917.png", rgb=True, record_pos=(0.357, -0.166), resolution=(2280, 1080)),'signIn':Template(r"tpl1549449873274.png", rgb=True, record_pos=(0.33, -0.091), resolution=(2280, 1080))}
    return photos[name]

# 大厅识别图片
def lobby_p(webside):
    photos = {'huihuang100':Template(r"tpl1549854612152.png", threshold=0.9, rgb=True, record_pos=(-0.35, -0.001), resolution=(1920, 1080)),,'wangzhe':Template(r"tpl1550736517471.png", rgb=True, record_pos=(-0.387, -0.003), resolution=(2160, 1080)),'yaoji':Template(r"tpl1550736442046.png", rgb=True, record_pos=(-0.363, -0.009), resolution=(2160, 1080))}
    return photos[webside]

# 下载游戏图片
def download_p(webside):
    photos = {'wangzhe':Template(r"tpl1550713661468.png", rgb=True, record_pos=(-0.104, -0.068), resolution=(2160, 1080)),'huihuang100':Template(r"tpl1549269461273.png", rgb=True, record_pos=(-0.103, 0.081), resolution=(2280, 1080))
    ,'yaoji':Template(r"tpl1550714352368.png", rgb=True, record_pos=(-0.138, -0.084), resolution=(2160, 1080))}
    return photos[webside]
        
# 登录页识别图片
def login_p(webside,name):
    if webside == 'huihuang100':
        photos = {'poster':Template(r"tpl1548467116180.png",rgb=True, record_pos=(0.024, -0.103), resolution=(2280, 1080)),'service':Template(r"tpl1550726596185.png", rgb=True, record_pos=(0.377, -0.222), resolution=(2160, 1080)),'webside':Template(r"tpl1550726668529.png", rgb=True, record_pos=(0.435, -0.222), resolution=(2160, 1080))}
    elif webside == 'wangzhe':
        photos = {'poster':Template(r"tpl1550726265614.png", rgb=True, record_pos=(0.021, -0.061), resolution=(2160, 1080)),'service':Template(r"tpl1550726792209.png", rgb=True, record_pos=(0.341, -0.227), resolution=(2160, 1080)),'webside':Template(r"tpl1550726750221.png", rgb=True, record_pos=(0.237, -0.226), resolution=(2160, 1080))}
    elif webside == 'yaoji':
        photos = {'poster':Template(r"tpl1550732184214.png", rgb=True, record_pos=(0.003, -0.065), resolution=(2160, 1080)),'service':Template(r"tpl1550732199628.png", rgb=True, record_pos=(0.382, -0.218), resolution=(2160, 1080)),'webside':Template(r"tpl1550732212590.png", rgb=True, record_pos=(0.289, -0.215), resolution=(2160, 1080))}
    return photos[name]

# 登录方式按钮图片
def login_button_p(webside,name):
    if webside == 'huihuang100':
        photos = {'wechat':Template(r"tpl1549966994244.png", record_pos=(-0.294, 0.15), resolution=(2160, 1080)),'account':Template(r"tpl1548310699716.png",rgb=True, record_pos=(-0.074, 0.145), resolution=(2280, 1080)),'quick':Template(r"tpl1548319187527.png", rgb=True,record_pos=(0.021, 0.146), resolution=(2280, 1080)),'register':Template(r"tpl1549967033681.png", record_pos=(0.289, 0.15), resolution=(2160, 1080))}
    elif webside == 'wangzhe':
        photos = {'wechat':Template(r"tpl1550727053816.png", rgb=True, record_pos=(-0.244, 0.141), resolution=(2160, 1080)),'account':Template(r"tpl1550727066873.png", rgb=True, record_pos=(-0.076, 0.143), resolution=(2160, 1080)),'quick':Template(r"tpl1550727077583.png", rgb=True, record_pos=(0.09, 0.142), resolution=(2160, 1080)),'register':Template(r"tpl1550727088112.png", rgb=True, record_pos=(0.256, 0.143), resolution=(2160, 1080))}
    return photos[name]

# 账号登录输入框图片
def login_fill_p(webside,name):
    if webside == 'huihuang100':
        photos = {'login':Template(r"tpl1548385913345.png",rgb=True, record_pos=(0.017, -0.13), resolution=(2280, 1080)),'account':Template(r"tpl1548496950405.png", rgb=True,record_pos=(0.059, -0.046), resolution=(2280, 1080)),'password':Template(r"tpl1548497012484.png", rgb=True,record_pos=(0.018, 0.011), resolution=(2280, 1080)),'submit':Template(r"tpl1548318427099.png", rgb=True,record_pos=(-0.024, 0.084), resolution=(2280, 1080))}
    elif webside == 'wangzhe':
        photos = {'login':Template(r"tpl1550734276891.png", rgb=True, record_pos=(-0.001, -0.135), resolution=(2160, 1080)),'account':Template(r"tpl1550734300623.png", rgb=True, record_pos=(0.035, -0.046), resolution=(2160, 1080)),'password':Template(r"tpl1550734327451.png", rgb=True, record_pos=(-0.009, 0.011), resolution=(2160, 1080)),'submit':Template(r"tpl1550734251994.png", rgb=True, record_pos=(-0.004, 0.092), resolution=(2160, 1080))}
    elif webside == 'yaoji':
        photos = {'login':Template(r"tpl1550734365359.png", rgb=True, record_pos=(-0.177, -0.134), resolution=(2160, 1080)),'account':Template(r"tpl1550734373614.png", rgb=True, record_pos=(0.047, -0.026), resolution=(2160, 1080)),'password':Template(r"tpl1550734382180.png", rgb=True, record_pos=(-0.011, 0.033), resolution=(2160, 1080)),'submit':Template(r"tpl1550734391305.png", rgb=True, record_pos=(-0.006, 0.112), resolution=(2160, 1080))}

    return photos[name]



