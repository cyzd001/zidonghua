# -*- encoding=utf8 -*-
__author__ = "riddle"
import os
from airtest.core.api import *
path = os.path.abspath('..\..')+'\common\settings.air'
using(path)
from settings import *
from poco.drivers.android.uiautomation import AndroidUiautomationPoco
from poco.exceptions import PocoNoSuchNodeException
poco = AndroidUiautomationPoco(use_airtest_input=True, screenshot_each_action=False)


# 可维护的常量
LINK = 'm.huihuang100.com'
LOGO = Template(r"tpl1548984900307.png", rgb=True, record_pos=(-0.001, -0.76), resolution=(1080, 2280))
POSTER = Template(r"tpl1549007863186.png", record_pos=(-0.003, -0.432), resolution=(1080, 2280))
GAMES = Template(r"tpl1549006909466.png", rgb=True, record_pos=(-0.001, 0.002), resolution=(1080, 2160))
IOS = Template(r"tpl1549001539107.png", record_pos=(-0.255, 0.356), resolution=(1080, 2160))
IOS_EXPLAIN = Template(r"tpl1549001591089.png", rgb=True, record_pos=(-0.005, -0.713), resolution=(1080, 2160))
IOS_PROCE = Template(r"tpl1549002072422.png", rgb=True, record_pos=(0.001, -0.714), resolution=(1080, 2160))
SUBMIT = Template(r"tpl1550640744883.png", rgb=True, record_pos=(-0.002, 0.193), resolution=(1080, 2160))
FEATURE_PHOTOS = [Template(r"tpl1549008356833.png", record_pos=(0.002, -0.579), resolution=(1080, 2280)),Template(r"tpl1549008371859.png", record_pos=(0.004, -0.579), resolution=(1080, 2280)),Template(r"tpl1549008386866.png", record_pos=(0.004, -0.578), resolution=(1080, 2280))]
GOLDCARP = Template(r"tpl1549005514762.png", rgb=True, record_pos=(-0.228, -0.1), resolution=(1080, 2160))
THIRTY_SECOND = Template(r"tpl1549005913731.png", rgb=True, record_pos=(0.229, -0.102), resolution=(1080, 2160))
HUNDRED_CATTLE = Template(r"tpl1549006042153.png", rgb=True, record_pos=(-0.227, 0.412), resolution=(1080, 2160))
TWO_CATTLE = Template(r"tpl1549005974544.png", rgb=True, record_pos=(0.228, 0.656), resolution=(1080, 2160))
SHAKE = Template(r"tpl1549006102880.png", rgb=True, record_pos=(-0.227, 0.474), resolution=(1080, 2160))
BENZ_BMW = Template(r"tpl1549006154471.png", rgb=True, record_pos=(0.227, 0.469), resolution=(1080, 2160))
ICON = Template(r"tpl1549003572018.png", rgb=True, record_pos=(-0.381, 0.898), resolution=(1080, 2160))







class Portal:
    """门户网站"""
    def __init__(self):
        self.open_app()
        self.serching()

    def connect_bool(self):    
        return True
#     打开app
    def open_app(self):
        stop_app('com.android.chrome')
        sleep(2)
        start_app('com.android.chrome')  #启动对应app
                
#     输入网址搜索
    def serching(self):
        sleep(5)
        poco("com.android.chrome:id/url_bar").click()
        text(LINK)
        sleep(5)
        
#     LOGO
    def test_logo_1(self):
#         如果LOGO不存在，往上拉5次
        if not exists(LOGO):
            for x in range(3):
                swipe([520,620],[520,1800])
                sleep(0.5)

        bug_assert(LOGO, "logo是否存在")

            
#     海报
    def test_poster_2(self):
        bug_assert(POSTER,'是否有海报','没有海报')

    
#     游戏列表
    def test_games_3(self):
        bug_assert(GAMES,'游戏列表图片')

#     客服
    def test_service_4(self):
        swipe([520,1400],[520,700])
        poco("serviceUrl").click()#点击客服
        sleep(2)
        if not exists(SUBMIT):
            poco("inputbox").click()#点击输入框
            text('你好吗')
            poco("enter").click()#点击发送
            sleep(1)
            message = poco('historyItem').children()
            lit = []
            for m in message:
                try:
                    new = m.children().children().get_text()
                    lit.append(new)
                except PocoNoSuchNodeException as e:
                    print(e)
            try:
                assert_equal('你好吗' in lit,True,'测试发送消息') 
            except AssertionError:
                snapshot(filename=bug_dir("客服发送不出去消息"))
                print("客服发送不出去消息")
        keyevent("BACK")
        sleep(2)
        
#      下载   
    def test_download_5(self):  
        if poco(text='ios-button').exists():
            print('点击可以下载')
        else:
            print('点击不可下载')         
        
#     ios教程
    def test_teach_ios_6(self):
#         进入IOS安装说明
        touch(IOS)        
        sleep(2)
        bug_assert(IOS_EXPLAIN, "跳转IOS安装说明")
        
#         进入安装教程图
        poco(text='详细安装教程').click()
        sleep(2)
        bug_assert(IOS_PROCE, "跳转授信流程图")
            
#         往入拉5次    
        for x in range(5):
            swipe([520,1700],[520,550])
            sleep(0.5)
            
#         往上拉5次
        for x in range(5):
            swipe([520,620],[520,1800])
            sleep(0.5)

        keyevent("BACK")
        sleep(1.0)
        keyevent("BACK")
        sleep(1)
    
#     游戏特色
    def test_game_feature_7(self):
        swipe([520,1400],[520,800])
        bug_assert(FEATURE_PHOTOS[0], "特色图片1")
        bug_assert(FEATURE_PHOTOS[1], "特色图片2")
        bug_assert(FEATURE_PHOTOS[2], "特色图片3")
            
#     检查图标
    def test_icon_8(self):
        swipe([520,1700],[520,600])
        bug_assert(ICON,'app图标是否存在')

#     热门游戏
    def test_hot_game_9(self):
        bug_assert(GOLDCARP, "金蟾捕鱼图片")
        bug_assert(THIRTY_SECOND, "欢乐30秒图片")
        bug_assert(SHAKE, "摇一摇图片")
        bug_assert(BENZ_BMW, "奔驰宝马图片")            
        swipe([520,700],[520,1100])
        bug_assert(HUNDRED_CATTLE, "百人牛牛图片")
        bug_assert(TWO_CATTLE, "二人牛牛图片")

    
#     关闭app
    def test_close_app_10(self):
        sleep(1)
        stop_app('com.android.chrome')#需要关闭浏览器
