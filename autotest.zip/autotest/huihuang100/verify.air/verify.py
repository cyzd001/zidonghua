# -*- encoding=utf8 -*-
__author__ = "riddle"
__title__ = '识别验证码'
import os
from airtest.core.api import *
from PIL import Image, ImageEnhance
from pytesseract import *
import matplotlib.pyplot as plt
path = os.path.abspath('..\..')+'\common\settings.air'
using(path)
from settings import *


"""获取验证码并输出"""
def get_verify():
    snapshot(filename=verify_dir("verifyCode.jpg"))
    if exists(Template(r"tpl1548401684663.png", rgb=True,record_pos=(-0.119, -0.087), resolution=(2280, 1080))):        
        rangle = (1225, 440,1405, 490)
    else:
        rangle = (1225, 375,1405, 425)
    # 打开截图
    i = Image.open(verify_dir('verifyCode.jpg'))
    # 使用Image的crop函数，从截图中再次截取我们需要的区域
    imgry = i.crop(rangle)  # 使用Image的crop函数，从截图中再次截取我们需要的区域
    imgry.save(verify_dir('getVerifyCode.jpg'))

    im = Image.open(verify_dir('getVerifyCode.jpg'))
    im = im.convert('L')  # 图像加强，二值化
    sharpness = ImageEnhance.Contrast(im)  # 对比度增强
    sharp_img = sharpness.enhance(2.0)
    sharp_img.save(verify_dir('newVerifyCode.jpg'))
    newVerify = Image.open(verify_dir('newVerifyCode.jpg'))
    # 使用image_to_string识别验证码
    num = image_to_string(newVerify).replace(' ', '')  # 使用image_to_string识别验证码
    return num



