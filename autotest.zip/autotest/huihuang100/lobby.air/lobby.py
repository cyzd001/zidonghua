# -*- encoding=utf8 -*-
__author__ = "riddle"
__title__ = '游戏大厅'
from airtest.core.api import *
using('settings.air')
from settings import*
from random import randint
from airtest.core.error import TargetNotFoundError



class Lobby:
    """大厅信息"""
    #   大厅官网和logo        
    def test_logo(self):       
        bug_assert(Template(r"tpl1549935613623.png", rgb=True, record_pos=(0.232, -0.226), resolution=(2160, 1080)), "大厅官网显示")
        touch(Template(r"tpl1549935613623.png", rgb=True, record_pos=(0.232, -0.226), resolution=(2160, 1080)))            
        bug_assert(Template(r"tpl1550053779110.png", rgb=True, record_pos=(0.018, -0.002), resolution=(2160, 1080)), "官网显示")
        bug_assert(Template(r"tpl1548469100374.png",rgb=True, record_pos=(-0.334, -0.138), resolution=(2280, 1080)), "LOGO显示")
              
#     ID复制
    def test_id_copy(self):
        touch(coordinate([310,85]))        
        bug_assert(Template(r"tpl1550053707582.png", rgb=True, record_pos=(0.019, -0.001), resolution=(2160, 1080)), "ID复制成功")
            
#     余额按钮进入充值页面
    def test_balance(self):
#         点左边进入
        touch(Template(r"tpl1549171453163.png", rgb=True, record_pos=(-0.197, -0.212), resolution=(2280, 1080)))
        wait(Template(r"tpl1548499100055.png", rgb=True,record_pos=(0.022, -0.202), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1548935010007.png",rgb=True, record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
        sleep(1)
#         点右边进入
        touch(Template(r"tpl1549171483407.png", rgb=True, record_pos=(-0.111, -0.212), resolution=(2280, 1080)))
        wait(Template(r"tpl1548499100055.png", rgb=True,record_pos=(0.022, -0.202), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1548935010007.png", rgb=True,record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
        sleep(1)
#         点中间进入
        touch(coordinate([690,52]))
        wait(Template(r"tpl1548499100055.png", rgb=True,record_pos=(0.022, -0.202), resolution=(2280, 1080)))
        sleep(1)
        touch(Template(r"tpl1548935010007.png", rgb=True,record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
        sleep(1)
        
#        消息 
    def test_news(self):
#         进入消息中心页
        touch(Template(r"tpl1549172081081.png", record_pos=(0.371, -0.214), resolution=(2280, 1080)))
        sleep(0.5)
        bug_assert(Template(r"tpl1548480165104.png",rgb=True, record_pos=(0.032, -0.175), resolution=(2280, 1080)), "进入消息中心")
        if exists(Template(r"tpl1549611018848.png", rgb=True, record_pos=(0.17, -0.105), resolution=(2160, 1080))):            
#             进入消息列表页
            touch(Template(r"tpl1549611018848.png", rgb=True, record_pos=(0.17, -0.105), resolution=(2160, 1080)))
            sleep(0.5)
            bug_assert(Template(r"tpl1548480390975.png",rgb=True, record_pos=(0.016, -0.131), resolution=(2280, 1080)), "读消息")
            
            touch(Template(r"tpl1549610865691.png", record_pos=(-0.003, 0.092), resolution=(2160, 1080)))
            sleep(0.5)
            touch(Template(r"tpl1549611050316.png", record_pos=(0.265, -0.104), resolution=(2160, 1080)))
            bug_assert_exists(Template(r"tpl1548480693862.png", rgb=True,record_pos=(-0.0, 0.001), resolution=(2280, 1080)), "删除消息")
            sleep(1)                        
            if not exists(Template(r"tpl1548483665087.png",rgb=True, record_pos=(0.014, -0.012), resolution=(2280, 1080))):
    #           全部删除进入提示页
                touch(Template(r"tpl1549611072117.png", rgb=True, record_pos=(-0.003, 0.141), resolution=(2160, 1080)))
                sleep(0.5)
                if exists(Template(r"tpl1548480892036.png", rgb=True,record_pos=(0.021, -0.129), resolution=(2280, 1080))): 
        #                 勾选不再提示
                    if exists(Template(r"tpl1548481185715.png", rgb=True,record_pos=(0.018, 0.04), resolution=(2280, 1080))):
                        touch(Template(r"tpl1549611144750.png", rgb=True, record_pos=(-0.065, 0.04), resolution=(2160, 1080)))                        
                        bug_assert(Template(r"tpl1548482172071.png",rgb=True, record_pos=(0.011, 0.039), resolution=(2280, 1080)), "勾选不再提示")

                    if exists(Template(r"tpl1548482172071.png",rgb=True, record_pos=(0.011, 0.039), resolution=(2280, 1080))):
                        touch(Template(r"tpl1549611165930.png", rgb=True, record_pos=(-0.064, 0.04), resolution=(2160, 1080)))                        
                        bug_assert(Template(r"tpl1548481185715.png",rgb=True, record_pos=(0.018, 0.04), resolution=(2280, 1080)), "取消勾选不再提示")
                    touch(Template(r"tpl1549610865691.png", record_pos=(-0.003, 0.092), resolution=(2160, 1080)))
                    
#                 有提示和无提示都要执行    
                sleep(1)                
                bug_assert(Template(r"tpl1548483665087.png",rgb=True, record_pos=(0.014, -0.012), resolution=(2280, 1080)), "全部删除")

        else:
            print('--------------------------没有任何消息---------------------------')
                                
                
#       关闭消息窗口     
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)
        
#     签到
    def signIn(self):
        touch(Template(r"tpl1549963312065.png", rgb=True, record_pos=(0.42, -0.226), resolution=(2160, 1080)))
        wait(Template(r"tpl1549963323648.png", rgb=True, record_pos=(0.003, -0.198), resolution=(2160, 1080)))
        touch(Template(r"tpl1549963379377.png", rgb=True, record_pos=(0.278, -0.017), resolution=(2160, 1080)))
        bug_assert(Template(r"tpl1549963410576.png", rgb=True, record_pos=(0.003, 0.0), resolution=(2160, 1080)),'领取时间未到')
        touch(Template(r"tpl1549963456819.png", record_pos=(0.355, -0.175), resolution=(2160, 1080)))
        sleep(1)
          
#     客服按钮
    def test_service(self):
        touch(coordinate([140,50]))
        sleep(2)
        try:
            if exists(Template(r"tpl1548653424574.png", rgb=True,record_pos=(0.292, -0.142), resolution=(2280, 1080))):
                touch(Template(r"tpl1548653424574.png", rgb=True,record_pos=(0.292, -0.142), resolution=(2280, 1080)))
                sleep(2)
                if not exists(Template(r"tpl1549936785021.png", rgb=True, record_pos=(-0.006, 0.0), resolution=(2160, 1080))):
                    if not exists(Template(r"tpl1548653247443.png", rgb=True,record_pos=(0.034, -0.175), resolution=(2280, 1080))):
                        keyevent("BACK")
                        sleep(2)
                    else:
                        raise ClickInvalidError("个人中心-客服按钮点击失败")
                else:                        
                    raise ControlOrAgentNotSetError("个人中心-未配置客服链接")
            else:
                raise TargetNotFoundError('个人中心-没有客服图标')
        except AirtestError:
            pass
#             关闭窗口
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)
        
#    头像       
    def test_avatar(self):
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))
        #如果不是个人资料的情况下
        if exists(Template(r"tpl1548728635920.png",rgb=True, record_pos=(0.106, 0.118), resolution=(2280, 1080))):
            sleep(10)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)
        elif exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)

        touch([960,460])#点击头像
        sleep(1)
        for x in range(10):
            swipe(coordinate([1300,550]),coordinate([700,565]))
            if exists(Template(r"tpl1549611498004.png", rgb=True, record_pos=(-0.146, -0.044), resolution=(2160, 1080))):
                break

        touch(Template(r"tpl1549611498004.png", rgb=True, record_pos=(-0.146, -0.044), resolution=(2160, 1080)))#点击头像
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))#关闭选择头像窗口
        sleep(1.0)
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))#关闭个人中心
        sleep(1.0)
        bug_assert(Template(r"tpl1548469670620.png", rgb=True,record_pos=(-0.4, -0.209), resolution=(2280, 1080)), "头像更改成功")        

#    性别
    def test_gender(self): 
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))
        #如果不是个人资料的情况下
        if exists(Template(r"tpl1548728635920.png",rgb=True, record_pos=(0.106, 0.118), resolution=(2280, 1080))):
            sleep(10)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)
        elif exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)


        if exists(Template(r"tpl1548639105276.png",rgb=True, record_pos=(0.117, -0.023), resolution=(2280, 1080))):
            touch(coordinate([1440,475]))
            bug_assert(Template(r"tpl1548639227763.png",rgb=True, record_pos=(0.185, -0.025), resolution=(2280, 1080)), "勾选女")


        if exists(Template(r"tpl1548639227763.png",rgb=True, record_pos=(0.185, -0.025), resolution=(2280, 1080))):
            touch(coordinate([1280,480]))
            bug_assert(Template(r"tpl1548639105276.png",rgb=True, record_pos=(0.117, -0.023), resolution=(2280, 1080)), "勾选男")

#                  关闭窗口
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)

#    改昵称
    def test_nickname(self):
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))        
        #如果不是个人资料的情况下
        if exists(Template(r"tpl1548728635920.png",rgb=True, record_pos=(0.106, 0.118), resolution=(2280, 1080))):
            sleep(10)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)
        elif exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)

        
        touch(coordinate([1360,415]))
        for x in range(10):
            keyevent('DEL')
        text('检查改昵称')
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))  #关闭窗口    
        sleep(1.0)       
        bug_assert(Template(r"tpl1548471439405.png", rgb=True,record_pos=(-0.334, -0.216), resolution=(2280, 1080)), "昵称更改")        
                
#       个人资料
    def test_personnalInfo(self):
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))       
        #如果不是个人资料的情况下
        if exists(Template(r"tpl1548728635920.png",rgb=True, record_pos=(0.106, 0.118), resolution=(2280, 1080))):
            sleep(10)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)
        elif exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,280]))#点击个人资料
            sleep(1)


        if exists(Template(r"tpl1548639529121.png",rgb=True, record_pos=(0.104, 0.124), resolution=(2280, 1080))):
            touch(Template(r"tpl1548639529121.png",rgb=True, record_pos=(0.104, 0.124), resolution=(2280, 1080)))
            wait(Template(r"tpl1549949496762.png", record_pos=(-0.002, -0.162), resolution=(2160, 1080)))
#                 验证码
            verify = get_verify()
            yzm = exists(Template(r"tpl1548399992933.png", threshold=0.9, rgb=True, record_pos=(-0.029, -0.035), resolution=(2280, 1080)))
            if yzm:
                touch(yzm)                               
                text(verify)            
            else:
                touch([1020,400])
                for x in range(6):
                    keyevent("DEL")
                text(verify)


    #         输入密码
            password = input('请输入密码：')
            if exists(Template(r"tpl1548383291958.png", rgb=True,record_pos=(0.0, -0.021), resolution=(2280, 1080))):
                touch(coordinate([1020,480]))             
                text(password)

    #         清除再输入密码
            else:
                touch(coordinate([1020,480]))    
                for x in range(15):
                    keyevent("DEL")                    
                text(password)  

    #         输入确认密码

            if exists(Template(r"tpl1548330850864.png",rgb=True, record_pos=(-0.003, 0.022), resolution=(2280, 1080))):
                touch(coordinate([1020,575]))
                text(password)
    #         清除再输入确认密码                
            else:       
                touch(coordinate([1020,575]))
                for x in range(15):
                    keyevent("DEL")
                text(password)  
                     #         注册
            touch(Template(r"tpl1548333650320.png", rgb=True,record_pos=(0.016, 0.113), resolution=(2280, 1080)))  
            sleep(1.0)

        else:
            touch(coordinate([1340,548]))#点击手机号码位置
            if exists(Template(r"tpl1548641304445.png", rgb=True,record_pos=(0.016, -0.13), resolution=(2280, 1080))):
                touch(coordinate([1600,555]))
                phoneNo = randint(10,99)                    
                text('131111111{}'.format(phoneNo))                    
                touch(Template(r"tpl1548671017932.png",rgb=True, record_pos=(0.018, 0.078), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548644661224.png", rgb=True,record_pos=(0.026, 0.003), resolution=(2280, 1080)), "绑定手机号码")
                
            else:
                print('------------------手机已绑定号码---------------------')
            
#             微信绑定
            touch(coordinate([1340,620]))
            try:
                if not exists(Template(r"tpl1549950499803.png", record_pos=(0.0, 0.001), resolution=(2160, 1080))):               
                    if not exists(Template(r"tpl1548653247443.png", rgb=True,record_pos=(0.034, -0.175), resolution=(2280, 1080))):
                        keyevent("BACK")
                        sleep(2)
                        if not exists(Template(r"tpl1548653247443.png", rgb=True,record_pos=(0.034, -0.175), resolution=(2280, 1080))):#回不来再back一次
                            keyevent("BACK")
                            sleep(2)
                    else:
                        raise ClickInvalidError("个人中心-微信绑定点击")
                else:                        
                    print("-------------------个人中心-未配置客服链接------------------")
            except ClickInvalidError:
                pass
                
#                 银行卡绑定
            touch(coordinate([1570,810]))# 点击银行卡绑定
            if not exists(Template(r"tpl1548753160408.png",rgb=True, record_pos=(0.025, -0.205), resolution=(2280, 1080))):
                touch(Template(r"tpl1549950882994.png", record_pos=(0.275, -0.147), resolution=(2160, 1080)))
                sleep(1.0)

#                 支付宝绑定
                touch(coordinate([1055,810]))#点击支付宝绑定
                wait(Template(r"tpl1548644924157.png", rgb=True,record_pos=(0.016, -0.13), resolution=(2280, 1080)))
                touch(coordinate([1050,495]))
                text('刘德华')
                touch(Template(r"tpl1549950978993.png", rgb=True, target_pos=4, record_pos=(0.007, 0.052), resolution=(2160, 1080)))
                touch(Template(r"tpl1548645137329.png",rgb=True, record_pos=(0.016, 0.088), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548646308000.png", rgb=True,record_pos=(0.028, 0.013), resolution=(2280, 1080)), "测试绑定支付宝")

#                     已经绑定过真实姓名
            else:
                print('----------------账号已经绑定过真实姓名----------------')
                touch(Template(r"tpl1549612297372.png", record_pos=(-0.41, -0.219), resolution=(2160, 1080)))
                sleep(1.0)

#                   关闭窗口
            touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
            sleep(1.0)

#       游戏记录
    def test_gameRecord(self):
        touch(coordinate([140,50]))#点击头像
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))
        #如果不是游戏记录的情况下
        if exists(Template(r"tpl1548728635920.png",rgb=True, record_pos=(0.106, 0.118), resolution=(2280, 1080))):
            sleep(8)
            touch(coordinate([510,440]))#点击游戏记录
            sleep(3)
        elif exists(Template(r"tpl1550051271521.png", record_pos=(0.141, -0.026), resolution=(2160, 1080))):
            sleep(1)
            touch(coordinate([510,440]))#点击游戏记录
            sleep(3)      

#             关闭窗口
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)

#       充提记录
    def test_monnyRecord(self):
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))
        #如果不是充提记录的情况下
        if exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,575]))#点击充提记录
            sleep(6)
        elif exists(Template(r"tpl1550051271521.png", record_pos=(0.141, -0.026), resolution=(2160, 1080))):
            sleep(1)
            touch(coordinate([510,575]))#点击充提记录
            sleep(6)
        else:
            sleep(6)
            touch(coordinate([510,575]))#点击充提记录
            sleep(6)


#             关闭窗口
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)

#       登录日志
    def test_loginRecord(self):
        touch(coordinate([140,50]))
        wait(Template(r"tpl1548653247443.png",rgb=True, record_pos=(0.034, -0.175), resolution=(2280, 1080)))
        #如果不是登录记录的情况下
        if exists(Template(r"tpl1548728670571.png", record_pos=(0.107, -0.071), resolution=(2280, 1080))):
            sleep(3)
            touch(coordinate([510,720]))#点击登录记录
            sleep(10)
        elif exists(Template(r"tpl1550051271521.png", record_pos=(0.141, -0.026), resolution=(2160, 1080))):
            sleep(1)
            touch(coordinate([510,720]))#点击登录记录
            sleep(10)     
        else:
            sleep(6)
            touch(coordinate([510,720]))#点击登录记录
            sleep(6)

#             关闭窗口
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)

        
class Menu: 
    """大厅菜单"""
#     活动页
    def test_activity_1(self):
        touch(Template(r"tpl1549612429386.png", record_pos=(-0.426, 0.219), resolution=(2160, 1080)))
        sleep(0.5)
        
#       平台公告
        touch(Template(r"tpl1549612453036.png", rgb=True, record_pos=(0.209, -0.121), resolution=(2160, 1080)))         
        bug_assert(Template(r"tpl1548473455673.png", rgb=True,record_pos=(0.218, -0.115), resolution=(2280, 1080)), "公告点击")

            

#         活动任务      
        touch(Template(r"tpl1549612474887.png", record_pos=(-0.04, -0.121), resolution=(2160, 1080)))
        bug_assert(Template(r"tpl1548473578117.png", rgb=True,record_pos=(-0.018, -0.117), resolution=(2280, 1080)), "测试任务点击")

        
#         关闭按钮
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)

#     客服页
    def test_service_2(self):
        try:
            if exists(Template(r"tpl1549612532326.png", record_pos=(-0.141, 0.219), resolution=(2160, 1080))):
                touch(Template(r"tpl1549612532326.png", record_pos=(-0.141, 0.219), resolution=(2160, 1080)))
                sleep(2)
                if not exists(Template(r"tpl1549936785021.png", rgb=True, record_pos=(-0.006, 0.0), resolution=(2160, 1080))):
                    if not exists(Template(r"tpl1549951752163.png", rgb=True, record_pos=(-0.365, 0.001), resolution=(2160, 1080))):
                        keyevent("BACK")
                        sleep(2)
                    else:
                        raise ClickInvalidError("菜单-客服按钮点击失败")
                else:                        
                    raise ControlOrAgentNotSetError("菜单-未配置客服链接")
            else:
                raise TargetNotFoundError('菜单-没有客服图标')
        except AirtestError:
            pass

#     保险箱
    def test_safe_box_3(self):
        touch(Template(r"tpl1549612559885.png", record_pos=(0.006, 0.22), resolution=(2160, 1080)))
        sleep(1)
            
#         设置密码
        if exists(Template(r"tpl1548485404745.png",rgb=True, record_pos=(0.023, -0.129), resolution=(2280, 1080))):
            double_click(coordinate([1200,490]))
            text('a123456')
            
            touch(coordinate([1200,580]))
            text('a123456')
            
            touch(Template(r"tpl1548485504198.png",rgb=True, record_pos=(0.015, 0.09), resolution=(2280, 1080)))
            sleep(1)
                        
#             关掉重新打开
            touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1549612559885.png", record_pos=(0.006, 0.22), resolution=(2160, 1080)))

            
        wait(Template(r"tpl1548486609024.png", rgb=True,record_pos=(0.021, -0.13), resolution=(2280, 1080)))
#           存钱
        touch(Template(r"tpl1548487261827.png", rgb=True,record_pos=(-0.227, -0.047), resolution=(2280, 1080)))
        sleep(1)

#             先点击最大按钮
        touch(Template(r"tpl1548487444282.png",rgb=True, record_pos=(0.281, -0.014), resolution=(2280, 1080)))
        bug_assert(Template(r"tpl1548487529006.png", rgb=True,record_pos=(0.085, -0.019), resolution=(2280, 1080)), "保险箱-存入金额拉条")
        

#             点击重置按钮
        touch(Template(r"tpl1548487485275.png", rgb=True,record_pos=(0.209, -0.061), resolution=(2280, 1080)))
        result = bug_assert(Template(r"tpl1548487663477.png", rgb=True,record_pos=(0.059, -0.059), resolution=(2280, 1080)), "保险箱-存入重置按钮")
        if not result:        
            for x in range(10):
                keyevent('DEL')

#             输入金额存钱
        try:
            if not exists(Template(r"tpl1548492010576.png", rgb=True,record_pos=(-0.004, -0.108), resolution=(2280, 1080))):
                touch(coordinate([1230,400]))
                keyevent('DEL')
                text('1')
                touch(Template(r"tpl1548488752558.png",rgb=True, record_pos=(0.104, 0.1), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548489796659.png",rgb=True, record_pos=(0.037, -0.004), resolution=(2280, 1080)), "保险箱存入金额")
                sleep(1)
            else:
                raise ControlOrAgentNotSetError("金额为0,无法存入")
        except ControlOrAgentNotSetError:
            pass

#             取钱        
        touch(Template(r"tpl1548488948817.png", rgb=True,record_pos=(-0.229, -0.104), resolution=(2280, 1080)))
        sleep(1)

#             先点击最大按钮
        touch(Template(r"tpl1548487444282.png",rgb=True, record_pos=(0.281, -0.014), resolution=(2280, 1080)))
        bug_assert(Template(r"tpl1548487529006.png", rgb=True,record_pos=(0.085, -0.019), resolution=(2280, 1080)), "保险箱-取出金额拉条")

#             点击重置按钮
        touch(Template(r"tpl1548487485275.png", rgb=True,record_pos=(0.209, -0.061), resolution=(2280, 1080)))
        result = bug_assert(Template(r"tpl1548489061869.png", rgb=True,record_pos=(0.054, -0.061), resolution=(2280, 1080)), "保险箱-取出重置按钮")
        if not result:        
            for x in range(10):
                keyevent('DEL')

#             输入金额取钱
        try:
            if not exists(Template(r"tpl1548492411251.png", threshold=0.9500000000000002, rgb=True, record_pos=(0.218, -0.111), resolution=(2280, 1080))):
                touch(coordinate([1300,400]))
                keyevent('DEL')
                text('1')            
                touch(Template(r"tpl1548488752558.png",rgb=True, record_pos=(0.104, 0.1), resolution=(2280, 1080)))            
                bug_assert(Template(r"tpl1548490011383.png",rgb=True, record_pos=(0.039, -0.001), resolution=(2280, 1080)), "测试取出金额")
                sleep(1)
            else:
                raise ControlOrAgentNotSetError("保险箱余额为0,无法取出")
        except ControlOrAgentNotSetError:
            pass

#             点击存取明细
        touch(Template(r"tpl1548489247942.png",rgb=True, record_pos=(-0.228, 0.016), resolution=(2280, 1080))) 
        sleep(2)

#         关闭按钮
        touch(Template(r"tpl1549611223613.png", rgb=True, record_pos=(0.367, -0.189), resolution=(2160, 1080)))
        sleep(1.0)
    
#     推广
    def test_publilarize_4(self):
        touch(Template(r"tpl1549952886919.png", record_pos=(-0.285, 0.219), resolution=(2160, 1080)))
        wait(Template(r"tpl1549952932864.png", record_pos=(0.046, -0.221), resolution=(2160, 1080)))
        def my():
            touch(Template(r"tpl1549962670654.png", record_pos=(-0.43, -0.148), resolution=(2160, 1080)))
            sleep(1)
#
                
#             保存按钮
            def save():
                touch(Template(r"tpl1549962757989.png", rgb=True, record_pos=(0.191, 0.15), resolution=(2160, 1080)))
                result = bug_assert(Template(r"tpl1548664996547.png",rgb=True, record_pos=(0.01, 0.0), resolution=(2280, 1080)), "保存模板按钮")
                if not result:
                    allow = exists(Template(r"tpl1549962787081.png", rgb=True, record_pos=(0.093, 0.082), resolution=(2160, 1080)))
                    try:
                        if allow:
                            touch(allow)
                            bug_assert(Template(r"tpl1548664996547.png",rgb=True, record_pos=(0.01, 0.0), resolution=(2280, 1080)), "保存模板按钮")
                        else:
                            raise ClickInvalidError('推广保存模板按钮失效')
                    except ClickInvalidError:
                        pass
            
#              复制链接
            def copy_link():
                touch(Template(r"tpl1549962886124.png", rgb=True, record_pos=(0.386, 0.149), resolution=(2160, 1080)))
                bug_assert(Template(r"tpl1549962937870.png", record_pos=(-0.005, -0.001), resolution=(2160, 1080)),'复制按钮')

#             提取记录
            def extract_record():
                touch(Template(r"tpl1549963047784.png", rgb=True, record_pos=(0.194, 0.201), resolution=(2160, 1080)))
                wait(Template(r"tpl1549963060813.png", rgb=True, record_pos=(0.053, -0.22), resolution=(2160, 1080)))
                bug_assert(Template(r"tpl1549963083639.png", rgb=True, record_pos=(0.004, 0.169), resolution=(2160, 1080)),'进入提取记录页')
                touch(Template(r"tpl1549963122251.png", record_pos=(-0.441, -0.219), resolution=(2160, 1080)))
                sleep(1)

#             帮助信息
            def help_info():
                touch(Template(r"tpl1549963178742.png", rgb=True, record_pos=(0.387, 0.204), resolution=(2160, 1080)))
                wait(Template(r"tpl1549963194492.png", rgb=True, record_pos=(0.046, -0.222), resolution=(2160, 1080)))
                touch(Template(r"tpl1549963211641.png", rgb=True, record_pos=(-0.443, -0.222), resolution=(2160, 1080)))
                sleep(1)

            save()
            copy_link()      
            extract_record()
            help_info()
        
#         推广员信息
        def info():
            touch(Template(r"tpl1549962572766.png", record_pos=(-0.362, -0.073), resolution=(2160, 1080)))
            sleep(1)
            bug_assert(Template(r"tpl1550037204400.png", rgb=True, record_pos=(0.105, -0.081), resolution=(2160, 1080)),'进入推广信息页')
        
#         推广教程
        def course():
            touch(Template(r"tpl1549961850642.png", rgb=True, record_pos=(-0.36, 0.072), resolution=(2160, 1080)))
            sleep(1.0)
            bug_assert(Template(r"tpl1549961885863.png", rgb=True, record_pos=(0.066, -0.052), resolution=(2160, 1080)), "测试教程页")
        
#         推广明细
        def details():
            touch(Template(r"tpl1549962262124.png", rgb=True, record_pos=(-0.359, 0.002), resolution=(2160, 1080)))#点击推广明细
            sleep(1.0)
#         一级下级
            def left():
                touch(coordinate([770,850]))#一级下级
                wait(Template(r"tpl1549962336765.png", rgb=True, record_pos=(0.012, -0.194), resolution=(2160, 1080)))
                touch(coordinate([620,240]))#会员ID
                text('000000')

                touch(Template(r"tpl1548665588621.png", rgb=True,record_pos=(0.12, -0.131), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548665612722.png",rgb=True, record_pos=(0.013, -0.001), resolution=(2280, 1080)), "查询按钮")
    #             关闭窗口
                touch(Template(r"tpl1549962388834.png", rgb=True, record_pos=(0.367, -0.196), resolution=(2160, 1080)))
                sleep(1.0)

#         二级下级
            def middle():
                touch(coordinate([1320,850]))#二级下级
                wait(Template(r"tpl1549962336765.png", rgb=True, record_pos=(0.012, -0.194), resolution=(2160, 1080)))
                touch(coordinate([620,240]))
                text('000000')

                touch(Template(r"tpl1548665588621.png",rgb=True, record_pos=(0.12, -0.131), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548665612722.png",rgb=True, record_pos=(0.013, -0.001), resolution=(2280, 1080)), "查询按钮")
    #             关闭窗口
                touch(Template(r"tpl1549962388834.png", rgb=True, record_pos=(0.367, -0.196), resolution=(2160, 1080)))
                sleep(1.0)

#         三级下级
            def right():
                touch(coordinate([1800,850]))#三级下级
                wait(Template(r"tpl1549962336765.png", rgb=True, record_pos=(0.012, -0.194), resolution=(2160, 1080)))

                touch(coordinate([620,240]))
                text('000000')

                touch(Template(r"tpl1548665588621.png",rgb=True, record_pos=(0.12, -0.131), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548665612722.png",rgb=True, record_pos=(0.013, -0.001), resolution=(2280, 1080)), "查询按钮")
    #             关闭窗口
                touch(Template(r"tpl1549962388834.png", rgb=True, record_pos=(0.367, -0.196), resolution=(2160, 1080)))
                sleep(1.0)

            
            left()
            middle()
            right()

#         推广排行
        def ranking():
            touch(Template(r"tpl1550037324104.png", record_pos=(-0.362, 0.146), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1550037356353.png", record_pos=(0.108, -0.153), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1550037370282.png", record_pos=(0.353, -0.155), resolution=(2160, 1080)))
            sleep(1)
            touch(Template(r"tpl1550037385082.png", record_pos=(-0.137, -0.156), resolution=(2160, 1080)))
            sleep(1)
        
        my()
        info()
        course()
        details() 
        ranking()
#         关闭推广窗口
        touch(Template(r"tpl1549613057941.png", record_pos=(-0.453, -0.216), resolution=(2160, 1080)))
        sleep(1.0)
        
#     提现
    def test_withdraw_5(self):
        touch(Template(r"tpl1549612799800.png", rgb=True, record_pos=(0.303, 0.213), resolution=(2160, 1080)))#点击提现
        wait(Template(r"tpl1548655333007.png",rgb=True, record_pos=(0.017, -0.201), resolution=(2280, 1080)))

#         客服按钮
        def service():
            try:
                if exists(Template(r"tpl1549953386434.png", rgb=True, record_pos=(0.392, -0.22), resolution=(2160, 1080))):
                    touch(Template(r"tpl1549953386434.png", rgb=True, record_pos=(0.392, -0.22), resolution=(2160, 1080)))
                    sleep(2)
                    if not exists(Template(r"tpl1549936785021.png", rgb=True, record_pos=(-0.006, 0.0), resolution=(2160, 1080))):
                        if not exists(Template(r"tpl1549953297933.png", rgb=True, record_pos=(-0.001, -0.214), resolution=(2160, 1080))):
                            keyevent("BACK")
                            sleep(2)
                        else:
                            raise ClickInvalidError("提现-客服按钮点击失败")
                    else:                        
                        raise ControlOrAgentNotSetError("提现-未配置客服链接")
                else:
                    raise TargetNotFoundError('提现-没有客服图标')
            except AirtestError:
                pass
            
#         绑定支付宝
        def bind_alipay():
            touch(Template(r"tpl1548747821452.png", rgb=True,record_pos=(-0.289, -0.024), resolution=(2280, 1080)))
            sleep(1.0)           
            
            if exists(Template(r"tpl1549017927669.png", threshold=0.9, rgb=True, record_pos=(0.168, -0.007), resolution=(2160, 1080))):
                touch(coordinate([1400,525]))#输入支付宝账号
                text('test@huihuang.com')
                touch(Template(r"tpl1548656363021.png", rgb=True,record_pos=(0.127, 0.153), resolution=(2280, 1080)))
                bug_assert(Template(r"tpl1548656629020.png", rgb=True,record_pos=(-0.013, -0.005), resolution=(2280, 1080)), "绑定支付宝")
            else:
                print('---------------------已经绑定支付宝了---------------')

#         绑定银行卡
        def bind_bankcard():
            touch(Template(r"tpl1548747916320.png", rgb=True,record_pos=(-0.29, 0.046), resolution=(2280, 1080)))
            sleep(1.0)
            touch(Template(r"tpl1549612900916.png", rgb=True, record_pos=(0.253, -0.034), resolution=(2160, 1080)))
            result = bug_assert(Template(r"tpl1548656818037.png",rgb=True, record_pos=(0.129, 0.026), resolution=(2280, 1080)), "选择银行按钮")
            if result:
                touch(Template(r"tpl1549612900916.png", rgb=True, record_pos=(0.253, -0.034), resolution=(2160, 1080)))
            
            touch(coordinate([1380,555]))
            text('111111111111111')
            touch(Template(r"tpl1548657304610.png", rgb=True,record_pos=(0.128, 0.154), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548748188931.png",rgb=True, record_pos=(0.005, -0.002), resolution=(2280, 1080)), "绑定银行卡")
                
#         结算
        def settlement():
            touch(Template(r"tpl1548749151573.png",rgb=True, record_pos=(-0.32, -0.092), resolution=(2280, 1080)))
            sleep(1.0)
            
            def cannot_one():
                touch(coordinate([1380,365]))#输入
                text('1')
                touch(Template(r"tpl1548742047028.png", rgb=True,record_pos=(0.128, 0.154), resolution=(2280, 1080)))
                sleep(1)
                try:
                    a = exists(Template(r"tpl1548742822853.png", rgb=True, record_pos=(0.021, 0.003), resolution=(2280, 1080))) 
                    b = exists(Template(r"tpl1549015818865.png", rgb=True, record_pos=(0.016, 0.003), resolution=(2280, 1080)))
                    flag = any([a,b])
                    assert_equal(flag, True, "测试不可提现1元")              
                except AssertionError:
                    snapshot(filename=bug_dir("1元提现成功了.jpg"))
                    print("1元提现成功了")
                touch(Template(r"tpl1548742359079.png", rgb=True,record_pos=(0.017, 0.075), resolution=(2280, 1080)))
                sleep(1.0)

                    
            def can_ten():
                touch(coordinate([1380,365]))#输入
                text('10')
                touch(Template(r"tpl1548742047028.png",rgb=True, record_pos=(0.128, 0.154), resolution=(2280, 1080)))
                try:
                    a = exists(Template(r"tpl1549519637951.png", record_pos=(0.016, 0.004), resolution=(2280, 1080))) 
                    b = exists(Template(r"tpl1549015818865.png", rgb=True, record_pos=(0.016, 0.003), resolution=(2280, 1080)))
                    flag = any([a,b])
                    assert_equal(flag,True, "测试提现10元")
                except AssertionError:
                    snapshot(filename=bug_dir("10元提现失败.jpg"))
                    print("10元提现失败")
                touch(Template(r"tpl1548742359079.png",rgb=True, record_pos=(0.017, 0.075), resolution=(2280, 1080)))
                sleep(1.0)

                    
#           调用函数模块
            cannot_one()
            can_ten()
                
#         调用函数模块        
        service()   
        bind_alipay()
        bind_bankcard()
        settlement()
#       关闭窗口
        touch(Template(r"tpl1548935010007.png",rgb=True, record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
        sleep(1.0)

#     充值
    def test_recharge_6(self):
        touch(Template(r"tpl1549613016003.png", rgb=True, record_pos=(0.43, 0.208), resolution=(2160, 1080)))#点击充值
        wait(Template(r"tpl1548659909976.png",rgb=True, record_pos=(0.02, -0.2), resolution=(2280, 1080)))
#         客服按钮
        def service():
            try:
                if exists(Template(r"tpl1549953386434.png", rgb=True, record_pos=(0.392, -0.22), resolution=(2160, 1080))):
                    touch(Template(r"tpl1549953386434.png", rgb=True, record_pos=(0.392, -0.22), resolution=(2160, 1080)))
                    sleep(2)
                    if not exists(Template(r"tpl1549936785021.png", rgb=True, record_pos=(-0.006, 0.0), resolution=(2160, 1080))):
                        if not exists(Template(r"tpl1548659909976.png",rgb=True, record_pos=(0.02, -0.2), resolution=(2280, 1080))):
                            keyevent("BACK")
                            sleep(2)
                        else:
                            raise ClickInvalidError("充值-客服按钮点击失败")
                    else:                        
                        raise ControlOrAgentNotSetError("充值-未配置客服链接")
                else:
                    raise TargetNotFoundError('充值-没有客服图标')
            except AirtestError:
                pass

#         记录
        def record():
            touch(Template(r"tpl1548660603992.png", rgb=True,record_pos=(0.406, -0.204), resolution=(2280, 1080)))
            sleep(2)
            wait(Template(r"tpl1549954312273.png", record_pos=(0.001, 0.168), resolution=(2160, 1080)))
#            关闭窗口
            touch(Template(r"tpl1549613057941.png", record_pos=(-0.453, -0.216), resolution=(2160, 1080)))           
    
#         银联
        def unionpay():
            bug_assert(Template(r"tpl1548746463101.png", rgb=True,record_pos=(0.243, 0.067), resolution=(2280, 1080)), "测试快速金额按钮")


#             不输入金额测试    
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png", rgb=True,record_pos=(0.025, -0.001), resolution=(2280, 1080)), "测试无金额提交充值")
        
#         快捷
        def fastpay():          
            bug_assert(Template(r"tpl1548746463101.png", rgb=True,record_pos=(0.243, 0.067), resolution=(2280, 1080)), "测试快速金额按钮")
#             不输入金额测试    
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png", rgb=True,record_pos=(0.025, -0.001), resolution=(2280, 1080)), "测试无金额提交充值")

#         京东
        def JD():
            bug_assert(Template(r"tpl1548746463101.png", rgb=True,record_pos=(0.243, 0.067), resolution=(2280, 1080)), "测试快速金额按钮")
#             不输入金额测试    
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png", rgb=True,record_pos=(0.025, -0.001), resolution=(2280, 1080)), "测试无金额提交充值")

#         网银
        def ebank():            
            bug_assert(Template(r"tpl1548746463101.png", rgb=True,record_pos=(0.243, 0.067), resolution=(2280, 1080)), "测试快速金额按钮")
#             不输入金额测试    
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png", rgb=True,record_pos=(0.025, -0.001), resolution=(2280, 1080)), "测试无金额提交充值")
        
#         官方充值
        def official():
#         支付宝
            def alipay():
                for x in range(2):                
                    result = exists(Template(r"tpl1548660855130.png",rgb=True, record_pos=(-0.114, -0.009), resolution=(2280, 1080)))
                    if not result:
                        swipe(coordinate([355,800]),coordinate([355,400]))
                    else:
                        break
                if not result:
                    for x in range(2):
                        result = exists(Template(r"tpl1548660855130.png",rgb=True, record_pos=(-0.114, -0.009), resolution=(2280, 1080)))
                        if not result:
                            swipe(coordinate([355,400]),coordinate([355,800]))
                        else:
                            break                    
                if result:
                    touch(Template(r"tpl1548660855130.png",rgb=True, record_pos=(-0.114, -0.009), resolution=(2280, 1080)))
                    touch(Template(r"tpl1548661164661.png", rgb=True,record_pos=(0.294, 0.098), resolution=(2280, 1080)))
                    sleep(1.0)

                    touch(Template(r"tpl1548661986307.png",rgb=True, record_pos=(-0.166, 0.155), resolution=(2280, 1080)))                    
                    result = bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存支付宝二维码")
                    if not result:
                        allow = exists(Template(r"tpl1549697586577.png", record_pos=(0.146, 0.106), resolution=(1920, 1080)))
                        try:
                            if allow:
                                touch(allow)
                                bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存支付宝二维码")
                            else:
                                raise ClickInvalidError('点击保存支付宝二维码失效')
                        except ClickInvalidError:
                            pass



                    touch(coordinate([1550,500]))#存款姓名
                    text('刘德华')
                    touch(coordinate([1550,600]))#存款金额
                    text('1')

                    touch(Template(r"tpl1548661509014.png", rgb=True,record_pos=(0.214, 0.159), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548661576861.png",rgb=True, record_pos=(0.019, -0.131), resolution=(2280, 1080)))
                    bug_assert(Template(r"tpl1548661564388.png",rgb=True, record_pos=(0.018, -0.025), resolution=(2280, 1080)), "支付宝汇款")

                    touch(Template(r"tpl1548661655234.png",rgb=True, record_pos=(0.018, 0.075), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548659909976.png", rgb=True,record_pos=(0.02, -0.2), resolution=(2280, 1080)))
        #            关闭窗口
                    touch(Template(r"tpl1549613057941.png", record_pos=(-0.453, -0.216), resolution=(2160, 1080))) 
                    sleep(1.0)

#         微信
            def wechat():
                for x in range(2):                
                    result = exists(Template(r"tpl1548661791607.png",rgb=True, record_pos=(-0.113, -0.072), resolution=(2280, 1080)))
                    if not result:
                        swipe(coordinate([355,800]),coordinate([355,400]))
                    else:
                        break
                if not result:
                    for x in range(2):
                        result = exists(Template(r"tpl1548661791607.png",rgb=True, record_pos=(-0.113, -0.072), resolution=(2280, 1080)))
                        if not result:
                            swipe(coordinate([355,400]),coordinate([355,800]))
                        else:
                            break                    
                if result:

                    touch(Template(r"tpl1548661791607.png",rgb=True, record_pos=(-0.113, -0.072), resolution=(2280, 1080)))
                    touch(Template(r"tpl1548661164661.png", rgb=True,record_pos=(0.294, 0.098), resolution=(2280, 1080)))
                    sleep(1.0)

                    touch(Template(r"tpl1548661986307.png", rgb=True,record_pos=(-0.166, 0.155), resolution=(2280, 1080)))
                    result =bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存微信二维码")
                    if not result:
                        allow = exists(Template(r"tpl1549697586577.png", record_pos=(0.146, 0.106), resolution=(1920, 1080)))
                        try:
                            if allow:
                                touch(allow)
                                bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存微信二维码")
                            else:
                                raise ClickInvalidError('点击保存微信二维码失效')
                        except ClickInvalidErr:
                            pass



                    touch(coordinate([1550,500]))#存款姓名
                    text('刘德华')
                    touch(coordinate([1550,600]))#存款金额
                    text('1')         
                    touch(Template(r"tpl1548661509014.png", rgb=True,record_pos=(0.214, 0.159), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548661576861.png",rgb=True, record_pos=(0.019, -0.131), resolution=(2280, 1080)))
                    bug_assert(Template(r"tpl1548661564388.png", rgb=True,record_pos=(0.018, -0.025), resolution=(2280, 1080)), "微信汇款")

                    touch(Template(r"tpl1548661655234.png", rgb=True,record_pos=(0.018, 0.075), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548659909976.png",rgb=True, record_pos=(0.02, -0.2), resolution=(2280, 1080)))
        #            关闭窗口
                    touch(Template(r"tpl1548935010007.png",rgb=True, record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
                    sleep(1.0)
            
#         云闪付
            def cloudpay():
                for x in range(2):                
                    result = exists(Template(r"tpl1549959652379.png", rgb=True, record_pos=(-0.14, 0.117), resolution=(2160, 1080)))
                    if not result:
                        swipe(coordinate([355,800]),coordinate([355,400]))
                    else:
                        break
                if not result:
                    for x in range(2):
                        result = exists(Template(r"tpl1549959652379.png", rgb=True, record_pos=(-0.14, 0.117), resolution=(2160, 1080)))
                        if not result:
                            swipe(coordinate([355,400]),coordinate([355,800]))
                        else:
                            break                    
                if result:
                    touch(Template(r"tpl1549959652379.png", rgb=True, record_pos=(-0.14, 0.117), resolution=(2160, 1080)))
                    touch(Template(r"tpl1548661164661.png", rgb=True,record_pos=(0.294, 0.098), resolution=(2280, 1080)))
                    sleep(1.0)

                    touch(Template(r"tpl1548661986307.png",rgb=True, record_pos=(-0.166, 0.155), resolution=(2280, 1080)))
                    result = bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存云闪付二维码")
                    if not result:
                        allow = exists(Template(r"tpl1549697586577.png", record_pos=(0.146, 0.106), resolution=(1920, 1080)))
                        try:
                            if allow:
                                touch(allow)
                                bug_assert(Template(r"tpl1548662024108.png",rgb=True, record_pos=(0.024, -0.001), resolution=(2280, 1080)), "保存云闪付二维码")
                            else:
                                raise ClickInvalidError('点击保存云闪付二维码失效')
                        except ClickInvalidErr:
                            pass



                    touch(coordinate([1550,500]))#存款姓名
                    text('刘德华')
                    touch(coordinate([1550,600]))#存款金额
                    text('1')

                    touch(Template(r"tpl1548661509014.png", rgb=True,record_pos=(0.214, 0.159), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548661576861.png",rgb=True, record_pos=(0.019, -0.131), resolution=(2280, 1080)))
                    bug_assert(Template(r"tpl1548661564388.png",rgb=True, record_pos=(0.018, -0.025), resolution=(2280, 1080)), "云闪付汇款")

                    touch(Template(r"tpl1548661655234.png",rgb=True, record_pos=(0.018, 0.075), resolution=(2280, 1080)))
                    wait(Template(r"tpl1548659909976.png", rgb=True,record_pos=(0.02, -0.2), resolution=(2280, 1080)))
        #            关闭窗口
                    touch(Template(r"tpl1549613057941.png", record_pos=(-0.453, -0.216), resolution=(2160, 1080))) 
                    sleep(1.0)
            
#         银行卡
            def bankcard():
                for x in range(3):                
                    result = exists(Template(r"tpl1549960062156.png", rgb=True, record_pos=(-0.139, -0.075), resolution=(2160, 1080)))
                    if not result:
                        swipe(coordinate([355,800]),coordinate([355,400]))
                    else:
                        break
                if not result:
                    for x in range(3):
                        result = exists(Template(r"tpl1549960062156.png", rgb=True, record_pos=(-0.139, -0.075), resolution=(2160, 1080)))
                        if not result:
                            swipe(coordinate([355,400]),coordinate([355,800]))
                        else:
                            break                    
                if result:
                    touch(Template(r"tpl1549960062156.png", rgb=True, record_pos=(-0.139, -0.075), resolution=(2160, 1080)))
                    touch(Template(r"tpl1548661164661.png", rgb=True,record_pos=(0.294, 0.098), resolution=(2280, 1080)))
                    sleep(1)
                    touch(Template(r"tpl1549960151792.png", record_pos=(-0.123, -0.07), resolution=(2160, 1080)))
                    bug_assert(Template(r"tpl1549960179516.png", record_pos=(-0.002, -0.002), resolution=(2160, 1080)),'复制银行卡信息')
                    touch(Template(r"tpl1549960225420.png", record_pos=(0.252, 0.167), resolution=(2160, 1080)))
                    bug_assert(Template(r"tpl1549960254305.png", record_pos=(-0.004, -0.002), resolution=(2160, 1080)),'提交申请按钮')
        #            关闭窗口
                    touch(Template(r"tpl1549613057941.png", record_pos=(-0.453, -0.216), resolution=(2160, 1080))) 
                    sleep(1.0) 

            alipay()
            wechat()       
            bankcard()
            cloudpay()
        
#         代理充值
        def agent():
#             举报代理
            def complaint():             
                touch(Template(r"tpl1548662345770.png",rgb=True, record_pos=(0.352, -0.082), resolution=(2280, 1080)))
                wait(Template(r"tpl1548662586164.png",rgb=True, record_pos=(0.024, -0.132), resolution=(2280, 1080)))
                touch(Template(r"tpl1548662603062.png",rgb=True, record_pos=(0.156, 0.079), resolution=(2280, 1080)))
                sleep(2)
                if not exists(Template(r"tpl1549617520916.png", record_pos=(-0.001, -0.0), resolution=(2160, 1080))):
                    result = bug_assert_not(Template(r"tpl1548662586164.png",rgb=True, record_pos=(0.024, -0.132), resolution=(2280, 1080)),'测试举报按钮跳转QQ')
                    if result:
                        keyevent("BACK")
                        sleep(2)


#                 关闭举报窗口
                touch(Template(r"tpl1549616981426.png", record_pos=(0.272, -0.147), resolution=(2160, 1080)))
                sleep(1.0)

#             复制
            def copy():
                wait(Template(r"tpl1548659909976.png",rgb=True, record_pos=(0.02, -0.2), resolution=(2280, 1080)))
                touch(Template(r"tpl1549617196342.png", record_pos=(0.348, 0.081), resolution=(2160, 1080)))
                try:
                    assert_exists(Template(r"tpl1548662904301.png",rgb=True, record_pos=(0.019, 0.0), resolution=(2280, 1080)), "测试复制按钮")
                except AssertionError:
                    snapshot(filename=bug_dir("复制按钮失效.jpg"))
                    print("复制按钮失效")
            
#             复制前往
            def leave_for():
                touch(Template(r"tpl1548663198134.png", rgb=True,record_pos=(0.26, 0.153), resolution=(2280, 1080)))
                sleep(2)
                if not exists(Template(r"tpl1549617364649.png", record_pos=(-0.005, -0.0), resolution=(2160, 1080))):
                    result = bug_assert_not(Template(r"tpl1548659909976.png", rgb=True,record_pos=(0.02, -0.2), resolution=(2280, 1080)),'复制前往按钮跳转微信')
                    if result:
                        keyevent("BACK")
                        sleep(2)
        
            complaint()
            copy()
            leave_for()
            
#         支付宝
        def alipay():          
            bug_assert(Template(r"tpl1548746463101.png",rgb=True, record_pos=(0.243, 0.067), resolution=(2280, 1080)), "快速金额按钮")


#             不输入金额测试    
            touch(Template(r"tpl1548746543990.png",rgb=True, record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png",rgb=True, record_pos=(0.025, -0.001), resolution=(2280, 1080)), "无金额提交充值")

#             输入金额跳转    
            touch(coordinate([1700,590]))
            text('8888')
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            sleep(2)
            if not exists(Template(r"tpl1549685109960.png", record_pos=(-0.007, -0.0), resolution=(2160, 1080))):   
                result =bug_assert_not(Template(r"tpl1548659909976.png",rgb=True, record_pos=(0.02, -0.2), resolution=(2280, 1080)), "提交充值跳转")
                if result:
                    keyevent("BACK")
                    sleep(2)

#         微信
        def wechat():
          
            bug_assert(Template(r"tpl1548746463101.png", rgb=True,record_pos=(0.243, 0.067), resolution=(2280, 1080)), "测试快速金额按钮")

    #             不输入金额测试    
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            bug_assert(Template(r"tpl1548746670071.png", rgb=True,record_pos=(0.025, -0.001), resolution=(2280, 1080)), "测试无金额提交充值")


    #             输入金额跳转    
            touch(coordinate([1700,590]))
            text('8888')
            touch(Template(r"tpl1548746543990.png", rgb=True,record_pos=(0.241, 0.121), resolution=(2280, 1080)))
            sleep(2)
            if not exists(Template(r"tpl1549685267805.png", record_pos=(-0.006, -0.001), resolution=(2160, 1080))):
                result = bug_assert_not(Template(r"tpl1548659909976.png", rgb=True,record_pos=(0.02, -0.2), resolution=(2280, 1080)), "提交充值跳转")
                if result:
                    keyevent("BACK")
                    sleep(2)

#         公众号
        def public():
            touch(Template(r"tpl1549960857520.png", record_pos=(0.269, 0.027), resolution=(2160, 1080)))
            bug_assert(Template(r"tpl1549960877291.png", record_pos=(-0.002, -0.001), resolution=(2160, 1080)),'复制按钮')
            touch(Template(r"tpl1549960929341.png", record_pos=(0.137, 0.101), resolution=(2160, 1080)))
            if exists(Template(r"tpl1549960964619.png", record_pos=(-0.006, -0.001), resolution=(2160, 1080))):
                print('---------------------手机未安装微信------------------------')
            else:
                pass

#         运行公众模块
        def runner():
            ways = {unionpay:Template(r"tpl1549956196954.png", threshold=0.9, rgb=False, record_pos=(-0.372, -0.116), resolution=(2160, 1080)),fastpay:Template(r"tpl1549958492436.png", threshold=0.9, rgb=False, record_pos=(-0.374, -0.036), resolution=(2160, 1080)),JD:Template(r"tpl1549958652438.png", threshold=0.9, rgb=False, record_pos=(-0.371, 0.035), resolution=(2160, 1080)),ebank:Template(r"tpl1549958843988.png", threshold=0.9, rgb=False, record_pos=(-0.373, 0.11), resolution=(2160, 1080)),official:Template(r"tpl1548743202121.png", threshold=0.9, rgb=False, record_pos=(-0.34, 0.035), resolution=(2280, 1080)),agent:Template(r"tpl1548745002008.png", threshold=0.9, rgb=False, record_pos=(-0.336, 0.104), resolution=(2280, 1080)),alipay:Template(r"tpl1548745092423.png", threshold=0.9, rgb=False, record_pos=(-0.332, -0.105), resolution=(2280, 1080)),wechat:Template(r"tpl1548745110933.png", threshold=0.9, rgb=False, record_pos=(-0.336, -0.035), resolution=(2280, 1080)),public:Template(r"tpl1549960802328.png", threshold=0.9, rgb=False, record_pos=(-0.307, 0.16), resolution=(2160, 1080))}            
            for way in ways:
                for x in range(3):                
                    result = exists(ways[way])
                    if not result:
                        swipe(coordinate([355,800]),coordinate([355,400]))
                    else:
                        break
                if not result:
                    for x in range(3):
                        result = exists(ways[way])
                        if not result:
                            swipe(coordinate([355,400]),coordinate([355,800]))
                        else:
                            break
                if result:
                    touch(ways[way])
                    sleep(1)
                    way()
                    
                    


#         调用函数模块
        service()
        record()
        runner()

#       关闭窗口
        touch(Template(r"tpl1548935010007.png",rgb=True, record_pos=(-0.451, -0.217), resolution=(2160, 1080)))
        sleep(1.0)

#     设置
    def test_settings_7(self):
        touch(Template(r"tpl1549613245893.png", rgb=True, record_pos=(0.147, 0.221), resolution=(2160, 1080)))
        wait(Template(r"tpl1548658565966.png", rgb=True,record_pos=(0.018, -0.131), resolution=(2280, 1080)))
        
        if exists(Template(r"tpl1548658592346.png",rgb=True, record_pos=(-0.068, -0.003), resolution=(2280, 1080))):
            touch(coordinate([850,475]))
            touch(coordinate([850,575]))            
            bug_assert(Template(r"tpl1548658686873.png",rgb=True, record_pos=(-0.069, -0.003), resolution=(2280, 1080)), "音乐和音效按钮")

                
        if exists(Template(r"tpl1548658686873.png",rgb=True, record_pos=(-0.069, -0.003), resolution=(2280, 1080))):
            touch(coordinate([850,475]))
            touch(coordinate([850,575]))
            bug_assert(Template(r"tpl1548658592346.png", rgb=True,record_pos=(-0.068, -0.003), resolution=(2280, 1080)), "音乐和音效按钮")


        touch(Template(r"tpl1548658919458.png",rgb=True, record_pos=(0.125, 0.071), resolution=(2280, 1080)))
        wait(Template(r"tpl1548658932261.png", rgb=True,record_pos=(0.02, -0.132), resolution=(2280, 1080)))
        touch(Template(r"tpl1548658946293.png", rgb=True,record_pos=(0.016, 0.068), resolution=(2280, 1080)))
        sleep(5)
        bug_assert_not(Template(r"tpl1548658565966.png", rgb=True,record_pos=(0.018, -0.131), resolution=(2280, 1080)),'退出到登录页')


    
    

        

