# -*- encoding=utf8 -*-
__author__ = "riddle"
__title__ = '登录页'
import os
from airtest.core.api import *
from random import randint
path = os.path.abspath('..\..')
using(path + r'\huihuang100\verify.air')
from verify import *
using(path+'\common\settings.air')
from settings import *



class Login_page:
    def __init__(self,webside):
        self.webside = webside
        self.inlobby_time = 15

        self.customer_service()
        self.official_webside()
    # 检查客服链接
    def customer_service(self):
        touch(login_p(self.webside,'service'))
        sleep(3)
        if exists(login_p(self.webside,'poster')):
            try:
                raise ClickInvalidError('客户图标失效')
            except ClickInvalidError:
                pass

        else:
            keyevent("BACK")
            sleep(2)
            if not exists(login_p(self.webside,'poster')):
                keyevent("BACK")
                sleep(2)
        
    # 官网        
    def official_webside(self):  
        touch(login_p(self.webside,'webside'))
        sleep(3)
        if exists(login_p(self.webside,'poster')):
            try:
                raise ClickInvalidError('官网图标点击无效')
            except ClickInvalidError:
                pass
        else:
            keyevent("BACK")
            sleep(1)
            if not exists(login_p(self.webside,'poster')):
                keyevent("BACK")
                sleep(2)
                        
    # 账号登录
    def account_login(self,account_phoneNo=None,password=None):
#         循环登录10次
        for x in range(10):
            wait(login_p(self.webside,'poster'))
#             判断账号登录按钮在不在？
            if exists(login_button_p(self.webside,'account')):
                touch(login_button_p(self.webside,'account'))
                wait(login_fill_p(self.webside,'login')) 

        #       输入账号
                account_fill = exists(login_fill_p(self.webside,'account'))
                if account_fill:        
                    touch(account_fill)
                    text(account_phoneNo)       
                else:
                    touch(account_fill)
                    for x in range(15):
                        keyevent("DEL")
                    text(account_phoneNo)


            #     输入密码
                password_fill = exists(login_fill_p(self.webside,'password'))
                if password_fill:
                    touch(password_fill)             
                    text(password)
                else:
                    touch(password_fill)   
                    for x in range(15):
                        keyevent("DEL")
                    text(password)               


        #         登录
                touch(login_fill_p(self.webside,'submit'))
                sleep(self.inlobby_time)
                notLogin = bug_assert_not(login_fill_p(self.webside,'login'),'登录页进入大厅') 
                if notLogin:
                    #关闭窗口 
                    islobby = close_windows(self.webside)
                    if islobby:
                        return True
                    else:
                        if exists(login_p(self.webside,'poster')):
                            print('-------------------环境问题-----------------')
                            sleep(5)
                            reboot_app(self.webside)
                        else:
                            print('-------------------在游戏中-------------------')
                            return False
                else:
#                     重新循环登录
                    reboot_app(self.webside)         
            else:
                wechat = exists(login_button_p(self.webside,'wechat'))
                quicklogin = exists(login_button_p(self.webside,'quick'))
                register = exists(login_button_p(self.webside,'register'))
                
                if any([wechat,quicklogin,register]):
                    print('------------账号登录禁用，请进入代理设置-----------------')
                else:
                    print('------------------------环境问题-----------------------------')
                sleep(5)
                reboot_app(self.webside) 
                
            print('\n环境异常休息10秒，重新启动中.................................\n')    
            sleep(10)#固定睡觉
            
        return False
        
    # 快速登录
    def quick_login(self):
        for x in range(10):
            wait(login_p(self.webside,'poster'))

            #     判断快速登录按钮在不在？
            if exists(login_button_p(self.webside,'quick')):
                touch(login_button_p(self.webside,'quick'))
                sleep(self.inlobby_time)
                bug_assert_not(login_button_p(self.webside,'quick'),'快速登录')    
                return close_windows()#关闭窗口  

            else:
                wechat = exists(login_button_p(self.webside,'wechat'))
                quicklogin = exists(login_button_p(self.webside,'quick'))
                register = exists(login_button_p(self.webside,'register'))

                if any([wechat,quicklogin,register]):
                    print('------------快捷登录禁用，请进入代理设置-----------------')
                else:
                    print('------------------------环境问题-----------------------------')
                    sleep(5)
                    reboot_app(self.webside) 
                    
                    
            print('\n环境异常休息10秒，重新启动中.................................\n')    
            sleep(10)#固定睡觉
                                       
    # 注册
    def register(self,account=None,phoneNo=None,password=None):
        #     判断注册按钮在不在？
        if exists(login_button_p(self.webside,'register')):
            touch(login_button_p(self.webside,'register'))
            wait(Template(r"tpl1548403103549.png",rgb=True, record_pos=(0.019, -0.152), resolution=(2280, 1080))) 
            
#             定义按钮坐标
            if exists(Template(r"tpl1548401684663.png", rgb=True,record_pos=(-0.119, -0.087), resolution=(2280, 1080))):
                account_phoneNo_fill = coordinate([1040,305])
                verify_fill = coordinate([1040,395])
                password_fill = coordinate([1040,490])
                cf_password_fill = coordinate([1040,570])
            else:
                account_phoneNo_fill = coordinate([1040,305])
                phoneNo_fill = coordinate([1040,385])
                verify_fill = coordinate([1040,450])
                password_fill = coordinate([1040,535])
                cf_password_fill = coordinate([1040,610])

#           定义删除信号
            DEL_FLAG = True
            
            while 1:
                rand = str(randint(100,999))
                if not phoneNo:
                    phoneNo = '13111111'+rand 
                if not account:                
                    account = 'riddle'+rand
                if not password:
                    password = 'a123456'               
                
#                 定义删除次数，为了加快速度
                if DEL_FLAG:
                    account_DEL = 15
                    phoneNo_DEL = 15
                    password_DEL = 15
                    verify_DEL = 6
                else:
                    account_DEL = 9
                    phoneNo_DEL = 11
                    password_DEL = 7
                    verify_DEL = 4
                    
                

        #         判断是否账号注册？
                if exists(Template(r"tpl1548324888336.png", rgb=True,record_pos=(-0.145, -0.101), resolution=(2280, 1080))):

        #             输入账号
                    if exists(Template(r"tpl1548329928444.png", rgb=True,record_pos=(0.023, -0.112), resolution=(2280, 1080))):
                        touch(account_phoneNo_fill)                   
                        text(account)

        #             清除再输入账号
                    else:
                        touch(account_phoneNo_fill)
                        for x in range(account_DEL):
                            keyevent("DEL")
                        text(account)


        #         判断是否手机号注册？
                if exists(Template(r"tpl1548321171783.png", rgb=True,record_pos=(-0.154, -0.101), resolution=(2280, 1080))):
                    if exists(Template(r"tpl1548401684663.png", record_pos=(-0.119, -0.087), resolution=(2280, 1080))):


                        if exists(Template(r"tpl1548321672184.png", rgb=True,record_pos=(-0.008, -0.1), resolution=(2280, 1080))):
                            touch(phoneNo_fill)
                            text(phoneNo)
                        else:
                            touch(phoneNo_fill)
                            for x in range(phoneNo_DEL):
                                keyevent("DEL")
                            text(phoneNo)

                    else:
                        if exists(Template(r"tpl1548321672184.png",rgb=True, record_pos=(-0.008, -0.1), resolution=(2280, 1080))):
                            touch(account_phoneNo_fill)
                            text(phoneNo)

                        else:
                            touch(account_phoneNo_fill)
                            for x in range(phoneNo):
                                keyevent("DEL")
                            text(phoneNo)

                            
#                 输入验证码               
                verify = get_verify()
                if exists(Template(r"tpl1548399992933.png", threshold=0.9, rgb=True, record_pos=(-0.029, -0.035), resolution=(2280, 1080))):
                    touch(verify_fill)                
                    text(verify)            
                else:
                    touch(verify_fill)
                    for x in range(verify_DEL):
                        keyevent("DEL")
                    text(verify)


        #         输入密码
                if exists(Template(r"tpl1548383291958.png", record_pos=(0.0, -0.021), resolution=(2280, 1080))):
                    touch(password_fill)             
                    text(password)

        #         清除再输入密码
                else:
                    touch(password_fill)
                    for x in range(password_DEL):
                        keyevent("DEL")
                    text(password)  


        #         输入确认密码
                if exists(Template(r"tpl1548330850864.png", record_pos=(-0.003, 0.022), resolution=(2280, 1080))):
                    touch(cf_password_fill)
                    text(password)
        #         清除再输入确认密码                
                else:             
                    touch(cf_password_fill)
                    for x in range(password_DEL):
                        keyevent("DEL")
                    text(password)  

        #         注册
                touch(login_button_p(self.webside,'register'))  
                sleep(self.inlobby_time)
                try:
                    assert_not_exists(Template(r"tpl1548403103549.png", record_pos=(0.019, -0.152), resolution=(2280, 1080)),'测试账号注册')
                    break
                except AssertionError :
                    DEL_FLAG = False
                    snapshot(filename=bug_dir("注册失败截图.jpg"))
                    print('注册失败！')


        else:
            print('快速登录按钮不存在，请进入代理设置')
            



