# -*- encoding=utf8 -*-
__author__ = "riddle"
__title__ = '主要执行调用模块'
import pyclbr
import os
from airtest.core.api import *
path = os.path.abspath('..\..')
using(path+'\common\settings.air')
from settings import *

using(path+'\games\games.air')
from games import *
import games

using(path+'\login\login.air')
from login import *



# 输入要跑的网站            
webside = 'yaoji' 
# 输入账号密码
account = 'cherry1'
password = 'a123456'
 



using(path+'\{}\lobby.air'.format(webside))
using(path+'\{}\portal.air'.format(webside))
from portal import *
from lobby import *


def main():  
    connect_phone()
    wake()
    
#    门户网站
#    第一个实例走流程，第二个实例是为了调用__init__用来关闭和打开浏览器包
#     test_class(Portal,4 ,webside,sort=True)
    

    if reboot_app(webside):#重启app
#         登录方式
        huihuang = Login_page(webside)
        huihuang.account_login(account,password)


    def login_again(webside):
        if reboot_app(webside):
#             重新调用原来的实例，就不会执行__init__部分
            return huihuang.account_login(account,password)
    
      
# #   大厅        
#     test_class(Lobby,login_again,webside)    
            
            
# #   大厅菜单
#     test_class(Menu,login_again,webside,sort=True)        
# #     再次登录，因为菜单里面有个设置是要退出游戏的
#     login_again(webside)
#     close_windows(webside)#关闭弹窗

# #     判断下载游戏
#     download_games(webside)
    
# #     游戏
#     game_list = [eval(x) for x in pyclbr.readmodule(games.__name__).keys() if x.startswith('Game_')]
#     game_list.reverse()#调换一下顺序
#     for game in game_list:            
#         test_game(game,login_again,webside)
        
    
#     游戏完毕，调用异常列表
    Except_list().show_except()               
main()



    
